<?php
// Database connection details
$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "eva_academy";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['submit'])) {
    $name = $_POST['fullname'];
    $fyda = $_POST['fyda_number'];

    // Insert data into the table
    $sql = "INSERT INTO teachers (fullname, fyda_number) VALUES ('$name', '$fyda')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Information saved successfully!'); window.location.href='index.php';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>