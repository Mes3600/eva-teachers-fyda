<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EVA Academy Collection</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .container { background: white; padding: 20px; border-radius: 8px; box-shadow: 0px 0px 10px rgba(0,0,0,0.1); width: 350px; }
        marquee { font-weight: bold; color: #2c3e50; margin-bottom: 20px; }
        input { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        button { width: 100%; padding: 10px; background-color: #27ae60; color: white; border: none; border-radius: 4px; cursor: pointer; }
        button:hover { background-color: #219150; }
    </style>
</head>
<body>

<div class="container">
    <marquee>EVA ACADEMY ONLINE TEACHERS INFORMATION COLLECTION</marquee>
    
    <form action="save.php" method="POST">
        <label>Full Name:</label>
        <input type="text" name="fullname" placeholder="Enter your full name" required>
        
        <label>FYDA Number:</label>
        <input type="text" name="fyda_number" placeholder="Enter your FYDA number" required>
        
        <button type="submit" name="submit">Submit Information</button>
    </form>
</div>

</body>
</html>
3. The Backend (save.php)
This script connects to your database and saves the teacher's information when they click "Submit."

PHP
<?php
// Database connection details
$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "eva_academy";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['submit'])) {
    $name = $_POST['fullname'];
    $fyda = $_POST['fyda_number'];

    // Insert data into the table
    $sql = "INSERT INTO teachers (fullname, fyda_number) VALUES ('$name', '$fyda')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Information saved successfully!'); window.location.href='index.php';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>